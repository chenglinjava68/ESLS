create function formatDateTime(fdate datetime)
  returns varchar(255)
  begin 
 
declare x varchar(255) default '';
 
set x= date_format(fdate,'%Y年%m月%d日%h时%i分%s秒');
 
return x;
 
end;

